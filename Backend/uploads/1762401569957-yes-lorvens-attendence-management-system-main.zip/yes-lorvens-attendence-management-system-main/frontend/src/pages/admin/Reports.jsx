import React from 'react';
import { FiCode, FiClock } from 'react-icons/fi';

const Reports = () => {
  return (
    <div className="p-6">
      {/* Page Header */}
      <div className="flex justify-between items-center mb-8">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Reports</h1>
      </div>

      {/* Development Stage Message */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-12">
        <div className="text-center">
          {/* Icon */}
          <div className="mx-auto flex items-center justify-center h-24 w-24 rounded-full bg-blue-100 dark:bg-blue-900/30 mb-6">
            <FiCode className="h-12 w-12 text-blue-600 dark:text-blue-400" />
          </div>
          
          {/* Title */}
          <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">
            Page Under Development
          </h2>
          
          {/* Description */}
          <p className="text-lg text-gray-600 dark:text-gray-300 mb-8 max-w-2xl mx-auto">
            The Reports page is currently being developed and will be available soon. 
            We're working hard to bring you comprehensive reporting features including 
            attendance summaries, detailed analytics, and exportable reports.
          </p>
          
          {/* Features Coming Soon */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-4xl mx-auto mb-8">
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-green-100 dark:bg-green-900/30 mb-4 mx-auto">
                <FiClock className="h-6 w-6 text-green-600 dark:text-green-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Attendance Reports
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Detailed attendance summaries with punch-in/out times, total hours, and status tracking.
              </p>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-purple-100 dark:bg-purple-900/30 mb-4 mx-auto">
                <FiCode className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Analytics Dashboard
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Visual charts and graphs showing attendance trends, patterns, and insights.
              </p>
            </div>
            
            <div className="bg-gray-50 dark:bg-gray-700 rounded-lg p-6">
              <div className="flex items-center justify-center h-12 w-12 rounded-full bg-orange-100 dark:bg-orange-900/30 mb-4 mx-auto">
                <FiClock className="h-6 w-6 text-orange-600 dark:text-orange-400" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-2">
                Export Features
              </h3>
              <p className="text-gray-600 dark:text-gray-300 text-sm">
                Export reports in multiple formats (PDF, Excel, CSV) for further analysis.
              </p>
            </div>
          </div>
          
          {/* Status */}
          <div className="inline-flex items-center px-4 py-2 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800 dark:bg-yellow-900/30 dark:text-yellow-300">
            <FiClock className="w-4 h-4 mr-2" />
            Coming Soon
          </div>
        </div>
      </div>
    </div>
  );
};

export default Reports; 