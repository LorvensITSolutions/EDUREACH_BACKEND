import { useEffect, useRef, useCallback } from "react";
import { useAuth } from "./useAuth";
import { employeeAPI } from "../services/api/employeeAPI";
import toast from "react-hot-toast";

const useIdleTimer = () => {
  const { user } = useAuth();
  const idleTimerRef = useRef(null);
  const autoPunchOutTimerRef = useRef(null);
  const isPunchedInRef = useRef(false);
  const eventListenersRef = useRef(null);
  const warningShownRef = useRef(false);

  // Configuration
  const IDLE_LIMIT = 17 * 60 * 1000;
  const WARNING_TIME = 15 * 60 * 1000;

  // Check if user is currently punched in
  const checkPunchStatus = useCallback(async () => {
    try {
      const response = await employeeAPI.getTodayStatus();
      const todayRecord = response.data.data;

      if (todayRecord && todayRecord.attendance) {
        const wasPunchedIn = isPunchedInRef.current;
        // Check if there's a current active session
        isPunchedInRef.current = !!todayRecord.attendance.currentSession;

        console.log("Punch status check:", {
          wasPunchedIn,
          isPunchedIn: isPunchedInRef.current,
          currentSession: todayRecord.attendance.currentSession,
          canPunchOut: todayRecord.attendance.canPunchOut,
          currentStatus: todayRecord.attendance.currentStatus,
        });
      } else {
        isPunchedInRef.current = false;
        console.log("No attendance data found");
      }
    } catch (error) {
      console.error("Error checking punch status:", error);
      isPunchedInRef.current = false;
    }
  }, []);

  // Auto punch out function
  const autoPunchOut = useCallback(async () => {
    if (!isPunchedInRef.current) return;

    try {
      console.log("Auto Punch Out triggered due to inactivity");

      // Show notification
      toast.error("You have been automatically punched out due to inactivity", {
        duration: 5000,
        position: "top-right",
      });

      // Call backend punch out
      await employeeAPI.punchOut();

      // Update punch status
      isPunchedInRef.current = false;
    } catch (error) {
      console.error("Error during auto punch out:", error);
      toast.error("Failed to auto punch out. Please punch out manually.", {
        duration: 5000,
        position: "top-right",
      });
    }
  }, []);

  // Clear all timers
  const clearAllTimers = useCallback(() => {
    if (idleTimerRef.current) {
      clearTimeout(idleTimerRef.current);
      idleTimerRef.current = null;
      console.log("Cleared warning timer");
    }
    if (autoPunchOutTimerRef.current) {
      clearTimeout(autoPunchOutTimerRef.current);
      autoPunchOutTimerRef.current = null;
      console.log("Cleared auto punch-out timer");
    }
    warningShownRef.current = false;
  }, []);

  // Set up activity event listeners
  const setupActivityListeners = useCallback(() => {
    if (eventListenersRef.current) {
      console.log("Activity listeners already set up");
      return; // Already set up
    }

    const activityEvents = [
      "mousemove",
      "keydown",
      "scroll",
      "click",
      "touchstart",
    ];
    const handleActivity = () => {
      console.log("Activity detected - resetting timer");
      resetIdleTimer();
    };

    // Add event listeners
    activityEvents.forEach((event) => {
      window.addEventListener(event, handleActivity, { passive: true });
      console.log(`Added event listener for: ${event}`);
    });

    eventListenersRef.current = { handleActivity, events: activityEvents };
    console.log("Activity listeners set up for events:", activityEvents);
  }, []);

  // Remove activity event listeners
  const removeActivityListeners = useCallback(() => {
    if (!eventListenersRef.current) return;

    const { handleActivity, events } = eventListenersRef.current;
    events.forEach((event) => {
      window.removeEventListener(event, handleActivity);
    });

    eventListenersRef.current = null;
    console.log("Activity listeners removed");
  }, []);

  // Reset idle timer
  const resetIdleTimer = useCallback(() => {
    if (!isPunchedInRef.current) return;

    // Clear existing timers
    clearAllTimers();

    warningShownRef.current = false;

    console.log("Resetting idle timer - user activity detected");

    // Set warning timer (1 minute)
    idleTimerRef.current = setTimeout(() => {
      console.log("Warning timer triggered");
      if (!warningShownRef.current) {
        warningShownRef.current = true;
        toast(
          "You will be automatically punched out in 15 min due to inactivity",
          {
            duration: 30000,
            position: "top-right",
            style: {
              background: "#fbbf24",
              color: "#1f2937",
            },
          }
        );
      }
    }, WARNING_TIME);

    // Set auto punch out timer (2 minutes)
    autoPunchOutTimerRef.current = setTimeout(() => {
      console.log("Auto punch-out timer triggered");
      if (isPunchedInRef.current) {
        autoPunchOut();
      }
    }, IDLE_LIMIT);
  }, [autoPunchOut, clearAllTimers]);

  // Initialize idle timer
  useEffect(() => {
    // Only set up idle timer for employees
    if (!user || user.role !== "employee") {
      console.log("Not an employee or no user - skipping idle timer setup");
      return;
    }
    console.log("Setting up idle timer for employee:", user.email);
    isPunchedInRef.current = false;
    clearAllTimers();
    removeActivityListeners();
    // Check initial punch status and set up timer
    const initializeTimer = async () => {
      await checkPunchStatus();

      // Only set up activity listeners and timer if punched in
      if (isPunchedInRef.current) {
        console.log("Employee is punched in - setting up idle timer");
        setupActivityListeners();
        resetIdleTimer();
      } else {
        // ...existing code...
        if (!user || user.role !== "employee") {
          console.log("Not an employee or no user - skipping idle timer setup");
          return;
        }
        warningShownRef.current = false;
        console.log("Setting up idle timer for employee:", user.email);
        // ...existing code...
        console.log("Employee is not punched in - no timer setup needed");
      }
    };

    initializeTimer();

    // Cleanup function
    return () => {
      console.log("Cleaning up idle timer");
      clearAllTimers();
      removeActivityListeners();
    };
  }, [
    user,
    checkPunchStatus,
    resetIdleTimer,
    setupActivityListeners,
    removeActivityListeners,
    clearAllTimers,
  ]);

  // Check punch status periodically (every 30 seconds)
  useEffect(() => {
    if (!user || user.role !== "employee") return;

    const interval = setInterval(async () => {
      const wasPunchedIn = isPunchedInRef.current;
      await checkPunchStatus();

      // If employee just punched in, start the timer
      if (!wasPunchedIn && isPunchedInRef.current) {
        console.log("Employee punched in - starting idle timer");
        setupActivityListeners();
        resetIdleTimer();
      }
      // If employee just punched out, clear the timer
      else if (wasPunchedIn && !isPunchedInRef.current) {
        console.log("Employee punched out - stopping idle timer");
        clearAllTimers();
        removeActivityListeners();
      }
    }, 30000); // 30 seconds

    return () => clearInterval(interval);
  }, [
    user,
    checkPunchStatus,
    resetIdleTimer,
    setupActivityListeners,
    removeActivityListeners,
    clearAllTimers,
  ]);

  return {
    isPunchedIn: isPunchedInRef.current,
    resetIdleTimer,
  };
};

export default useIdleTimer;
