import React, { useState, useEffect } from "react";
import { useAuth } from "../../hooks/useAuth";
import useIdleTimer from "../../hooks/useIdleTimer";

const IdleTimerIndicator = () => {
  const { user } = useAuth();
  const { isPunchedIn } = useIdleTimer();
  const [timeRemaining, setTimeRemaining] = useState(null);
  const [showWarning, setShowWarning] = useState(false);

  // Timer configuration (should match useIdleTimer)
  const IDLE_LIMIT = 17 * 60 * 1000; // 60 seconds for testing (normally 2 minutes)
  const WARNING_TIME = 15 * 60 * 1000; // 30 seconds warning for testing (normally 1 minute)

  // Update time remaining based on last activity
  useEffect(() => {
    if (!isPunchedIn) {
      setTimeRemaining(null);
      setShowWarning(false);
      return;
    }

    let lastActivity = Date.now();
    let warningShown = false;

    const handleActivity = () => {
      lastActivity = Date.now();
      if (warningShown) {
        setShowWarning(false);
        warningShown = false;
      }
    };

    // Listen for the same events as useIdleTimer
    const activityEvents = [
      "mousemove",
      "keydown",
      "scroll",
      "click",
      "touchstart",
    ];
    activityEvents.forEach((event) => {
      window.addEventListener(event, handleActivity, { passive: true });
    });

    const timer = setInterval(() => {
      const now = Date.now();
      const timeSinceActivity = now - lastActivity;

      if (timeSinceActivity >= IDLE_LIMIT) {
        setTimeRemaining(0);
        setShowWarning(false);
      } else if (timeSinceActivity >= WARNING_TIME) {
        const remaining = Math.ceil((IDLE_LIMIT - timeSinceActivity) / 1000);
        setTimeRemaining(remaining);
        if (!warningShown) {
          setShowWarning(true);
          warningShown = true;
        }
      } else {
        const remaining = Math.ceil((IDLE_LIMIT - timeSinceActivity) / 1000);
        setTimeRemaining(remaining);
        setShowWarning(false);
      }
    }, 1000);

    return () => {
      clearInterval(timer);
      activityEvents.forEach((event) => {
        window.removeEventListener(event, handleActivity);
      });
    };
  }, [isPunchedIn]);

  // Don't show indicator if not punched in
  if (!user || user.role !== "employee" || !isPunchedIn) {
    return null;
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins}:${secs.toString().padStart(2, "0")}`;
  };

  return (
    <div
      className={`fixed top-20 right-4 z-50 transition-all duration-300 ${
        showWarning ? "animate-pulse" : ""
      }`}
    >
      {/* <div
        className={`px-3 py-2 rounded-lg shadow-lg text-sm font-medium ${
          showWarning ? "bg-red-500 text-white" : "bg-blue-500 text-white"
        }`}
      > */}
      {/* <div className="flex items-center space-x-2">
          <svg
            className="w-4 h-4"
            fill="none"
            stroke="currentColor"
            viewBox="0 0 24 24"
          >
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z"
            />
          </svg>
          <span></span>
        </div> */}
      {/* </div> */}
    </div>
  );
};

export default IdleTimerIndicator;
