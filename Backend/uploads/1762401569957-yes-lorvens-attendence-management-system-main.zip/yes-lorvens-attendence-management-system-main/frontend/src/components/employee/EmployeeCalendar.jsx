import React, { useState, useEffect, useCallback } from 'react';
import { FiCalendar, FiClock, FiCheck, FiX, FiAlertCircle, FiLogIn, FiLogOut } from 'react-icons/fi';
import { formatTimeIST } from '../../utils/helpers';
import { useAuth } from '../../hooks/useAuth';
import { useAttendanceHistory, useTodayStatus } from '../../hooks/useAttendance';

const EmployeeCalendar = () => {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());

  // Get current month and year
  const currentMonth = currentDate.getMonth();
  const currentYear = currentDate.getFullYear();

  // Get days in current month
  const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
  const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();

  // Fetch attendance data for the current month using React Query
  const { data: attendanceResponse, isLoading: loading, error } = useAttendanceHistory({
    month: currentMonth + 1,
    year: currentYear,
  });

  // Get today's status to merge with calendar data
  const { data: todayStatus } = useTodayStatus();

  // Extract attendance data from the response and merge with today's data
  const attendanceData = useCallback(() => {
    if (!attendanceResponse) return [];
    
    let data = [];
    
    if (attendanceResponse && attendanceResponse.data) {
      if (Array.isArray(attendanceResponse.data)) {
        data = attendanceResponse.data;
      } else if (attendanceResponse.data.data && Array.isArray(attendanceResponse.data.data)) {
        data = attendanceResponse.data.data;
      } else if (attendanceResponse.data.attendance && Array.isArray(attendanceResponse.data.attendance)) {
        data = attendanceResponse.data.attendance;
      } else if (attendanceResponse.data.results && Array.isArray(attendanceResponse.data.results)) {
        data = attendanceResponse.data.results;
      } else if (attendanceResponse.data.records && Array.isArray(attendanceResponse.data.records)) {
        data = attendanceResponse.data.records;
      } else if (attendanceResponse.data.attendanceLogs && Array.isArray(attendanceResponse.data.attendanceLogs)) {
        data = attendanceResponse.data.attendanceLogs;
      } else if (attendanceResponse.data.data && attendanceResponse.data.data.attendanceLogs && Array.isArray(attendanceResponse.data.data.attendanceLogs)) {
        // Common shape from backend: { data: { attendanceLogs, pagination } }
        data = attendanceResponse.data.data.attendanceLogs;
      }
    }
    
    // Merge today's data if available
    if (todayStatus && todayStatus.attendance) {
      const today = new Date().toISOString().split('T')[0]; // YYYY-MM-DD format
      const todayRecord = {
        date: today,
        formattedDate: today,
        status: todayStatus.attendance.currentStatus || 'not-started',
        totalHours: todayStatus.attendance.totalHours || 0,
        firstPunchInTime: todayStatus.attendance.currentSession?.punchIn?.time,
        lastPunchOutTime: todayStatus.attendance.currentSession?.punchOut?.time,
        punchSessions: todayStatus.attendance.punchSessions || (todayStatus.attendance.currentSession ? [todayStatus.attendance.currentSession] : []),
        currentSessionStatus: todayStatus.attendance.currentSessionStatus
      };
      
      // Replace today's record if it exists, otherwise add it
      const existingTodayIndex = data.findIndex(record => {
        const recordDate = record.date || record.formattedDate || record.attendanceDate;
        return recordDate === today;
      });
      
      if (existingTodayIndex >= 0) {
        data[existingTodayIndex] = { ...data[existingTodayIndex], ...todayRecord };
      } else {
        data.unshift(todayRecord);
      }
    }
    
    return Array.isArray(data) ? data : [];
  }, [attendanceResponse, todayStatus]);

  // Navigate to previous month
  const goToPreviousMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth - 1, 1));
  };

  // Navigate to next month
  const goToNextMonth = () => {
    setCurrentDate(new Date(currentYear, currentMonth + 1, 1));
  };

  // Get attendance status for a specific date
  const getAttendanceStatus = (day) => {
    const data = attendanceData();
    if (!Array.isArray(data)) {
      return null;
    }
    // Normalize to IST date key for both calendar day and record date
    const dateKey = new Date(currentYear, currentMonth, day).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });

      const attendance = data.find(a => {
      const recordDate = a.date || a.formattedDate || a.attendanceDate;
      if (!recordDate) return false;
      const recKey = new Date(recordDate).toLocaleDateString('en-CA', { timeZone: 'Asia/Kolkata' });
      return recKey === dateKey;
    });
    return attendance;
  };

  // Derive a status when backend does not provide one
  const deriveStatus = (record) => {
    if (!record) return null;
    if (record.status) return record.status;
    const sessions = Array.isArray(record.punchSessions) ? record.punchSessions : [];
    const total = typeof record.totalHours === 'number' ? record.totalHours : sessions.reduce((sum, s) => sum + (s.sessionHours || 0), 0);
    if (sessions.length === 0 || total === 0) return 'absent';
    if (total < 4) return 'half-day';
    return 'present';
  };

  // Format time helper function
  const formatTime = (timeValue) => {
    if (!timeValue) return 'N/A';
    return formatTimeIST(timeValue, 'HH:mm');
  };

  // Get status display info
  const getStatusDisplay = (status, isToday = false) => {
    const statusConfig = {
      present: { 
        color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
        icon: <FiCheck className="w-4 h-4" />,
        text: 'Present'
      },
      absent: { 
        color: 'bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300',
        icon: <FiX className="w-4 h-4" />,
        text: 'Absent'
      },
      late: { 
        color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
        icon: <FiAlertCircle className="w-4 h-4" />,
        text: 'Late'
      },
      'half-day': { 
        color: 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300',
        icon: <FiClock className="w-4 h-4" />,
        text: 'Half Day'
      },
      leave: { 
        color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
        icon: <FiCalendar className="w-4 h-4" />,
        text: 'Leave'
      },
      'work-from-home': { 
        color: 'bg-indigo-100 text-indigo-800 dark:bg-indigo-900 dark:text-indigo-300',
        icon: <FiCalendar className="w-4 h-4" />,
        text: 'WFH'
      },
      'on-duty': { 
        color: 'bg-teal-100 text-teal-800 dark:bg-teal-900 dark:text-teal-300',
        icon: <FiCalendar className="w-4 h-4" />,
        text: 'On Duty'
      },
      completed: { 
        color: 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300',
        icon: <FiCheck className="w-4 h-4" />,
        text: 'Completed'
      },
      'punched-in': { 
        color: 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300',
        icon: <FiLogIn className="w-4 h-4" />,
        text: 'Punched In'
      },
      'in-progress': { 
        color: 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300',
        icon: <FiClock className="w-4 h-4" />,
        text: 'In Progress'
      },
      'not-started': { 
        color: 'bg-gray-100 text-gray-600 dark:bg-gray-700 dark:text-gray-400',
        icon: <FiX className="w-4 h-4" />,
        text: 'Not Started'
      },
      login: {
        color: 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900 dark:text-emerald-300',
        icon: <FiLogIn className="w-4 h-4" />,
        text: 'Login'
      },
      logout: {
        color: 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-300',
        icon: <FiLogOut className="w-4 h-4" />,
        text: 'Logout'
      }
    };

    return statusConfig[status] || { 
      color: 'bg-gray-100 text-gray-800 dark:bg-gray-700 dark:text-gray-300',
      icon: <FiCalendar className="w-4 h-4" />,
      text: status || 'No Record'
    };
  };

  // Generate calendar days
  const generateCalendarDays = () => {
    const days = [];
    
    // Add empty cells for days before the first day of the month
    for (let i = 0; i < firstDayOfMonth; i++) {
      days.push(<div key={`empty-${i}`} className="p-2"></div>);
    }

    // Add days of the month
    for (let day = 1; day <= daysInMonth; day++) {
      const attendance = getAttendanceStatus(day);
      const isToday = new Date().toDateString() === new Date(currentYear, currentMonth, day).toDateString();
      
      // Determine status display
      let statusDisplay;
      if (isToday && attendance && attendance.status !== 'work-from-home' && attendance.status !== 'on-duty' && attendance.status !== 'leave') {
        // Check if work day is completed (after 11:30 PM)
        const currentHour = new Date().getHours();
        const currentMinute = new Date().getMinutes();
        const isWorkDayCompleted = currentHour >= 23 || (currentHour === 23 && currentMinute >= 30);
        
        if (isWorkDayCompleted) {
          // After work day completion, show final status based on total hours
          const totalHours = attendance.totalHours || 0;
          
          if (totalHours > 7.5) {
            statusDisplay = getStatusDisplay('present');
          } else if (totalHours >= 4 && totalHours <= 7.5) {
            statusDisplay = getStatusDisplay('half-day');
          } else {
            statusDisplay = getStatusDisplay('absent');
          }
                 } else {
           // During work day, show working status
           if (attendance.punchSessions && attendance.punchSessions.length > 0) {
             const lastSession = attendance.punchSessions[attendance.punchSessions.length - 1];
             
             // Check if there's any punch-in activity
             const hasPunchIn = attendance.punchSessions.some(session => 
               session.punchIn && session.punchIn.time
             );
             
             if (lastSession.punchIn && lastSession.punchIn.time && lastSession.punchOut && lastSession.punchOut.time) {
               statusDisplay = getStatusDisplay('completed'); // Completed session
             } else if (hasPunchIn) {
               statusDisplay = getStatusDisplay('in-progress'); // In Progress (punched in at least once)
             } else {
               statusDisplay = getStatusDisplay('not-started');
             }
           } else {
             statusDisplay = getStatusDisplay('not-started');
           }
         }
      } else {
        // For other days, use attendance status
        const effectiveStatus = attendance ? deriveStatus(attendance) : null;
        statusDisplay = effectiveStatus ? getStatusDisplay(effectiveStatus) : getStatusDisplay();
      }

      days.push(
        <div 
          key={day} 
          className={`p-3 border border-gray-200 dark:border-gray-700 min-h-[120px] rounded-lg ${
            isToday ? 'bg-blue-50 dark:bg-blue-900/20 border-blue-300 dark:border-blue-600' : 'hover:bg-gray-50 dark:hover:bg-gray-700/50'
          } transition-colors duration-200`}
        >
          <div className="flex justify-between items-start mb-2">
            <span className={`text-sm font-medium ${
              isToday ? 'text-blue-600 dark:text-blue-400' : 'text-gray-900 dark:text-gray-100'
            }`}>
              {day}
            </span>
            {/* Always show status badge */}
            <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs space-x-1 ${statusDisplay.color}`}>
              {statusDisplay.icon}
              <span className="hidden md:inline">{statusDisplay.text}</span>
            </div>
          </div>
          
          {attendance && (
            <div className="text-xs text-gray-600 dark:text-gray-400 space-y-1">
              {isToday ? (
                // Show today's current session info
                <>
                  {attendance.firstPunchInTime && (
                    <div className="bg-emerald-50 dark:bg-emerald-900/20 px-2 py-1 rounded text-emerald-700 dark:text-emerald-300">
                      Login: {formatTime(attendance.firstPunchInTime)}
                    </div>
                  )}
                  {attendance.currentSessionStatus === 'active' && attendance.punchSessions && attendance.punchSessions.length > 0 && (
                    <div className="font-medium bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded text-blue-700 dark:text-blue-300">
                      {Math.floor(attendance.punchSessions[attendance.punchSessions.length - 1].sessionHours || 0)}h {Math.round(((attendance.punchSessions[attendance.punchSessions.length - 1].sessionHours || 0) % 1) * 60)}m
                    </div>
                  )}
                  {attendance.totalHours && (
                    <div className="font-medium bg-purple-50 dark:bg-purple-900/20 px-2 py-1 rounded text-purple-700 dark:text-purple-300">
                      Total: {Math.floor(attendance.totalHours)}h {Math.round((attendance.totalHours % 1) * 60)}m
                    </div>
                  )}
                </>
              ) : (
                // Show regular attendance info for other days
                <>
                  {attendance.firstPunchInTime && (
                    <div className="bg-gray-50 dark:bg-gray-700/50 px-2 py-1 rounded">
                      In: {formatTime(attendance.firstPunchInTime)}
                    </div>
                  )}
                  {attendance.lastPunchOutTime && (
                    <div className="bg-gray-50 dark:bg-gray-700/50 px-2 py-1 rounded">
                      Out: {formatTime(attendance.lastPunchOutTime)}
                    </div>
                  )}
                  {attendance.totalHours && (
                    <div className="font-medium bg-blue-50 dark:bg-blue-900/20 px-2 py-1 rounded text-blue-700 dark:text-blue-300">
                      {Math.floor(attendance.totalHours)}h {Math.round((attendance.totalHours % 1) * 60)}m
                    </div>
                  )}
                </>
              )}
            </div>
          )}
        </div>
      );
    }

    return days;
  };

  const monthNames = [
    'January', 'February', 'March', 'April', 'May', 'June',
    'July', 'August', 'September', 'October', 'November', 'December'
  ];

  return (
    <div className="p-6 space-y-6">
      {/* Page Header */}
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900 dark:text-white">Attendance Calendar</h1>
        <div className="text-sm text-gray-600 dark:text-gray-400">
          Welcome, {user?.name || 'Employee'}
        </div>
      </div>

      {/* Legend - Now First */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-3">Legend</h3>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-3">
          {[
            { status: 'present', text: 'Present' },
            { status: 'absent', text: 'Absent' },
            { status: 'late', text: 'Late' },
            { status: 'half-day', text: 'Half Day' },
            { status: 'leave', text: 'Leave' },
            { status: 'login', text: 'Login' },
            { status: 'logout', text: 'Logout' }
          ].map(({ status, text }) => {
            const statusDisplay = getStatusDisplay(status);
            return (
              <div key={status} className="flex items-center space-x-2">
                <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs ${statusDisplay.color}`}>
                  {statusDisplay.icon}
                </div>
                <span className="text-sm text-gray-700 dark:text-gray-300">{text}</span>
              </div>
            );
          })}
        </div>
      </div>

      {/* Calendar Navigation - Now Second */}
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-sm border border-gray-200 dark:border-gray-700 p-4">
        <div className="flex justify-between items-center mb-4">
          <button
            onClick={goToPreviousMonth}
            className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            ← Previous
          </button>
          
          <h2 className="text-xl font-semibold text-gray-900 dark:text-white">
            {monthNames[currentMonth]} {currentYear}
          </h2>
          
          <button
            onClick={goToNextMonth}
            className="p-2 text-gray-600 dark:text-gray-400 hover:text-gray-900 dark:hover:text-white transition-colors"
          >
            Next →
          </button>
        </div>

        {/* Loading State */}
        {loading && (
          <div className="text-center py-8">
            <div className="inline-flex items-center px-4 py-2 font-semibold leading-6 text-sm shadow rounded-md text-white bg-blue-500">
              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
              </svg>
              Loading attendance data...
            </div>
          </div>
        )}

        {/* Error State */}
        {error && (
          <div className="text-center py-8">
            <div className="inline-flex items-center px-4 py-2 font-semibold leading-6 text-sm shadow rounded-md text-white bg-red-500">
              <FiAlertCircle className="w-5 h-5 mr-2" />
              {error}
            </div>
          </div>
        )}

        {/* Calendar Grid */}
        {!loading && !error && (
          <div className="grid grid-cols-7 gap-2">
            {/* Day Headers */}
            {['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].map(day => (
              <div key={day} className="p-3 text-center text-sm font-medium text-gray-500 dark:text-gray-400 bg-gray-50 dark:bg-gray-700 rounded-lg">
                {day}
              </div>
            ))}
            
            {/* Calendar Days */}
            {generateCalendarDays()}
          </div>
        )}
      </div>
    </div>
  );
};

export default EmployeeCalendar; 